import type {Overview,AnswerRow} from "./answer-engine";

export const waiSources={
 current:"https://environment.govt.nz/acts-and-regulations/national-policy-statements/national-policy-statement-freshwater-management/",
 instrument:"https://environment.govt.nz/publications/national-policy-statement-for-freshwater-management/",
 explanation:"https://environment.govt.nz/publications/guidance-on-the-national-objectives-framework-of-the-nps-fm/clause-1-3/",
 tikanga:"https://www.watersafetynz.org/kia-maanu-kia-ora/wai-puna/tikanga",
 rights:"https://waimaori.maori.nz/faq-items/how-can-hapu-or-iwi-have-rights-to-water/",
 speech:"https://www.beehive.govt.nz/speech/indigenous-peoples-legal-water-forum",
 change:"https://www.taumataarowai.govt.nz/about-us/legislation/water-services-legislation-changes",
 rma:"https://www.legislation.govt.nz/act/public/1991/0069/latest/",
 data:"https://data.govt.nz/leadership/centre-for-data-ethics-and-innovation/guidance/maori-data-and-ai-guidance-for-business"
};
const row=(topic:string,answer:string,reference:string,url:string):AnswerRow=>({topic,answer,reference,url});
export function waiAnswer(question:string):Overview|null{
 const q=question.toLowerCase();
 if(!/te mana o te wai|tikanga|kaitiakitanga|mātauranga|matauranga|mauri|mana whenua|tangata whenua|hapū|hapu|iwi.*water|iwi.*wai|māori.*water|maori.*water|wai.*māori|wai.*maori|water.*rights|customary.*water/.test(q))return null;
 const rights=/rights|ownership|own water|allocation|proprietary|rangatiratanga/.test(q);
 const practice=/tikanga|water safety|swim|drown|wai puna/.test(q);
 return {
  summary:rights?"Hapū and iwi rights and interests in freshwater cannot be settled by a general answer. Te Wai Māori explains the significance of mana and customary rights, but its FAQ is an advocacy perspective, not a ruling for a particular water body. Check the applicable law, settlements, consents and local context with mana whenua and qualified advisers.":practice?"Tikanga comprises place- and community-specific practices informed by whakapapa and mātauranga. Water Safety NZ's Wai Puna framework describes tikanga as part of protecting whānau around water; it does not set drinking-water treatment or monitoring rules.":"Te Mana o te Wai remains the fundamental concept of the in-force National Policy Statement for Freshwater Management (NPS-FM). Its six principles and hierarchy guide freshwater management, especially regional council planning. Its effect on a project depends on the current regional plan, consents and local engagement with tangata whenua.",
  scope:"Do not treat a cultural account, an older speech or this summary as a supply-specific legal conclusion. The separate Water Services Act supplier duty to give effect to Te Mana o te Wai was removed in 2025; current drinking-water safety duties continue. Ask the relevant council and mana whenua about local freshwater decisions, and Taumata Arowai about unclear drinking-water supplier requirements.",
  rows:[
   row("Current national direction","The NPS-FM 2020, consolidated with December 2025 amendments and in force from 15 January 2026, directs local authorities on freshwater management under the RMA.","Ministry for the Environment · in-force NPS-FM",waiSources.current),
   row("Te Mana o te Wai","Clause 1.3 sets six principles and prioritises water bodies and ecosystems, then people's health needs such as drinking water, then other social, economic and cultural uses.","NPS-FM · clause 1.3",waiSources.instrument),
   row("Local application","Regional councils engage tangata whenua and communities to determine local application. Check your council's regional policy statement, freshwater plan and any relevant consent conditions.","MfE · clause 1.3 guidance",waiSources.explanation),
   row("Tikanga and water safety","Wai Puna describes tikanga as practices informed by whakapapa and mātauranga to protect whānau; local tikanga should be discussed with the appropriate people.","Water Safety NZ · Wai Puna: Tikanga",waiSources.tikanga),
   row("Hapū and iwi interests","Te Wai Māori explains its position on customary rights, mana and freshwater. It is a perspective on rights, not a determination of title or a supplier compliance rule.","Te Wai Māori · rights FAQ (2019)",waiSources.rights),
   row("Historical context","A 2009 ministerial speech describes connections to wai and calls for Māori involvement in freshwater governance. Read it as historical advocacy, not current law.","Beehive · Pita Sharples speech (2009)",waiSources.speech),
   row("Supplier duty changed","Taumata Arowai states that the Water Services Act requirement for suppliers to give effect to Te Mana o te Wai, where applicable, was removed in 2025.","Taumata Arowai · legislation changes",waiSources.change)
  ]
 };
}
