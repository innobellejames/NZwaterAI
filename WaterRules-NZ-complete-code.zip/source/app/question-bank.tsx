"use client";
import {useState} from "react";
import {ExternalLink,Search,Trash2} from "lucide-react";
import type {AnswerRow} from "./answer-engine";

export type SavedQuestion={id:string;askedAt:string;question:string;searchQuery:string;supply:string;summary:string;scope:string;rows:AnswerRow[]};

export default function QuestionBank({entries,onAskAgain,onDelete,onClear}:{entries:SavedQuestion[];onAskAgain:(q:string,supply:string)=>void;onDelete:(id:string)=>void;onClear:()=>void}){
 const [filter,setFilter]=useState("");
 const visible=entries.filter(item=>`${item.question} ${item.summary}`.toLowerCase().includes(filter.toLowerCase()));
 return <section className="question-bank"><p className="eyebrow">YOUR QUESTION BANK</p><h1>Return to what<br/><em>you asked.</em></h1><p className="lead">Questions and answer snapshots are saved in this browser on this device. They are not synced across devices. A saved answer may be out of date; open its sources or ask again to use the site's current indexed material.</p>
  {entries.length>0&&<div className="bank-controls"><label><Search size={17}/><span className="sr-only">Search saved questions</span><input value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Find a saved question"/></label><button onClick={onClear}><Trash2 size={15}/> Clear question bank</button></div>}
  {entries.length===0?<div className="empty">No saved questions yet. Ask a question to start your bank. Avoid entering sensitive supply or personal information.</div>:visible.length===0?<div className="empty">No saved questions match that search.</div>:<div className="bank-list">{visible.map(item=><article className="bank-card" key={item.id}><details><summary><span>{item.question}</span><small>{new Date(item.askedAt).toLocaleString("en-NZ",{dateStyle:"medium",timeStyle:"short",timeZone:"Pacific/Auckland"})} · {item.rows.length} sources</small></summary><div className="bank-content"><p className="bank-snapshot"><strong>Saved answer</strong> · This is a snapshot from the date above, not a live compliance check.</p><p>{item.summary}</p>{item.rows.length>0&&<div className="table-scroll"><table className="overview-table"><thead><tr><th scope="col">Topic</th><th scope="col">Saved answer</th><th scope="col">Source or reference</th></tr></thead><tbody>{item.rows.map((row,i)=><tr key={`${row.reference}-${i}`}><th scope="row">{row.topic}</th><td>{row.answer}</td><td><a href={row.url} target="_blank" rel="noopener noreferrer">{row.reference} <ExternalLink size={14}/></a></td></tr>)}</tbody></table></div>}<p className="scope-note">{item.scope}</p><div className="bank-actions"><button onClick={()=>onAskAgain(item.question,item.supply)}>Ask again with current site sources</button><button className="delete" onClick={()=>onDelete(item.id)}><Trash2 size={14}/> Delete</button></div></div></details></article>)}</div>}
  <p className="scope-note">Saved only in this browser's local storage. Anyone using this browser profile may see the bank. Clearing browser data or using another device removes access to these snapshots.</p>
 </section>;
}
