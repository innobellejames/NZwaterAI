import type {Overview} from "./answer-engine";
const standards="https://www.legislation.govt.nz/regulation/public/2022/0168/latest/whole.html";
const aesthetics="https://www.taumataarowai.govt.nz/assets/Uploads/Rules-and-standards/Taumata-Arowai-Aesthetic-Values-for-Drinking-Water-2022.pdf";
const row=(topic:string,answer:string,reference:string,url:string)=>({topic,answer,reference,url});
export function waterIssueAnswer(q:string):Overview|null{
 if(/fluorid|fluoride/.test(q))return {
  summary:"Fluoride questions have two separate parts: the legal drinking water limit and public health policy on community fluoridation. New Zealand's fluoride MAV is 1.5 mg/L; that is not a target concentration. Whether a local authority is directed to fluoridate a particular supply is a separate Ministry of Health decision.",
  scope:"Evidence at community fluoridation concentrations should not be equated with evidence from higher total exposure. Check the local supply's measured concentration, any current direction and monitoring records. Health concerns about a specific result need the supplier and public health advice.",
  rows:[
   row("Legal health limit","The Drinking Water Standards set the fluoride maximum acceptable value (MAV) at 1.5 mg/L.","2022 Standards · Schedule, Table 2",standards),
   row("Who decides fluoridation","The Director-General of Health may direct local authorities to fluoridate named supplies; consult the current directions and implementation status.","Ministry of Health · implementation","https://www.health.govt.nz/strategies-initiatives/programmes-and-initiatives/oral-health/implementation-of-community-water-fluoridation"),
   row("Benefits and known effects","The Ministry's 2024 evidence review finds fewer dental caries with community fluoridation; excess total intake can cause dental fluorosis, usually mild at NZ fluoridation levels.","Ministry of Health · evidence review (PDF)","https://www.health.govt.nz/system/files/2024-12/community-water-fluoridation-evidence-review.pdf"),
   row("Neurodevelopment evidence","The US NTP found a moderate-confidence association between higher fluoride exposure (often water above 1.5 mg/L) and lower child IQ. It found insufficient evidence to determine the effect of 0.7 mg/L in drinking water; association does not establish causation.","US NTP · 2024 systematic review","https://ntp.niehs.nih.gov/research/assessments/noncancer/completed/fluoride")
  ]};
 if(/nitrate|nitrite/.test(q))return {
  summary:"Nitrate has a short-term health MAV of 50 mg/L as nitrate (NO₃), equivalent to 11.3 mg/L as nitrate-nitrogen (NO₃-N). Compare a laboratory result only after checking which unit it uses. A result below the current MAV does not settle every question about long-term risk.",
  scope:"The MAV is designed to protect infants against methaemoglobinaemia. Research on other outcomes, including bowel cancer at lower concentrations, is still being evaluated; an observed association is not proof of causation. If the MAV is exceeded, protect consumers and contact Taumata Arowai and public health services through the required response process. Boiling does not remove nitrate.",
  rows:[
   row("Current limit and units","50 mg/L as NO₃ or 11.3 mg/L as NO₃-N are two ways of stating the same MAV; nitrate plus nitrite also has a combined ratio limit.","2022 Standards · Schedule, Table 2",standards),
   row("Immediate concern","High nitrate can cause methaemoglobinaemia, especially in bottle-fed infants. The regulator says an exceedance requires immediate public health action and notification.","Taumata Arowai · nitrate facts and figures","https://www.taumataarowai.govt.nz/home/articles/nitrate-in-drinking-water-facts-and-figures"),
   row("Boiling is not the response","Boiling water does not remove nitrate. Follow the supplier's Do Not Drink advice and arrange a suitable alternative supply when the MAV is exceeded.","Taumata Arowai · nitrate exceedance notice","https://www.taumataarowai.govt.nz/home/articles/do-not-drink-notice-issued-nitrate-levels-breach-acceptable-levels-in-lower-waihao-waimate-distri"),
   row("Long-term evidence","The Prime Minister's Chief Science Advisor describes reported bowel cancer associations in overseas studies while noting that whether the relationship is causal is unresolved.","Chief Science Advisor · nitrates","https://www.pmcsa.ac.nz/topics/nitrates/"),
   row("Recent NZ exposure research","A 2026 peer-reviewed study reconstructed historical nitrate concentrations for public distribution zones, including imputed gaps. Population estimates do not establish a current reading for your source or an individual's health outcome.","Chambers et al. · Water Environment Research (2026)","https://onlinelibrary.wiley.com/doi/10.1002/wer.70296"),
   row("Sampling and local risk","Check the Rules for your supply category and source; shallow private bores may be less routinely monitored. Arrange accredited testing and review the source water risk plan.","Taumata Arowai · nitrate monitoring","https://www.taumataarowai.govt.nz/home/articles/nitrate-in-drinking-water-facts-and-figures")
  ]};
 if(/manganese|\biron\b|rusty|brown water|discolou?r|stain|metallic taste|hardness|rotten egg|sulphur smell|sulfur smell/.test(q))return {
  summary:"Colour, staining, scale and unusual smells may be aesthetic complaints, but appearance alone cannot establish that water is safe. Identify the determinand and compare any test with both its aesthetic value and any health-based MAV.",
  scope:"A sudden change, persistent complaint or possible contamination needs investigation and the supplier's response process. Do not assume brown water is solely iron or manganese without sampling. For household-specific plumbing, check with the supply operator and a qualified professional.",
  rows:[
   row("Aesthetic examples","Iron has a staining value of 0.3 mg/L; manganese has 0.04 mg/L for staining and 0.10 mg/L for taste; hardness and pH can affect scale and corrosion.","Aesthetic Values Notice · Schedule, p. 2",`${aesthetics}#page=2`),
   row("Manganese health value","The Standards separately set a health-based MAV of 0.4 mg/L for manganese. The aesthetic values are lower and serve a different purpose.","2022 Standards · Schedule, Table 2",standards),
   row("Colour, taste and odour","The notice sets colour at ≤15 TCU and says taste and odour should be acceptable to most consumers. Hydrogen sulphide has an aesthetic value of ≤0.05 mg/L.","Aesthetic Values Notice · Schedule, pp. 2–3",aesthetics),
   row("Supplier response","Take all reasonably practicable steps to supply water complying with aesthetic values, while checking whether a change indicates a health or treatment issue.","Aesthetic Values Notice · purpose",aesthetics)
  ]};
 return null;
}
