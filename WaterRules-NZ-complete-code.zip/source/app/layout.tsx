import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "WaterRules NZ | Drinking water supplier requirements",
  description: "Explore New Zealand drinking water supplier requirements with linked official sources.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
