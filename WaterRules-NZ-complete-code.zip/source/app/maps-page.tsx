"use client";
import {useState} from "react";
import {ExternalLink} from "lucide-react";

const maps=[
 {area:"Nationwide",kind:"Registered drinking water supplies",name:"HineKōrako public registers",url:"https://hinekorako.taumataarowai.govt.nz/",note:"Supply register; it is not a pipe or bore inventory."},
 {area:"Nationwide (participating regions)",kind:"Wells / bores",name:"Wells Aotearoa",url:"https://wellsnz.teurukahika.nz/wells",note:"Search well records; coverage and completeness vary by council."},
 {area:"Nationwide monitoring sites",kind:"Groundwater quality",name:"LAWA groundwater quality",url:"https://www.lawa.org.nz/explore-data/groundwater-quality",note:"Monitoring sites and trends, not every private bore."},
 {area:"Auckland",kind:"Water and wastewater networks",name:"Watercare GIS viewer",url:"https://watercare.maps.arcgis.com/apps/webappviewer/index.html?id=3944a60cbf864b9494087cd39094e114",note:"Watercare assets; use its GIS guidance for interpretation and asset downloads."},
 {area:"Hamilton",kind:"Three waters infrastructure",name:"Hamilton City Waters Viewer",url:"https://hamilton.govt.nz/your-city/data-and-statistics/understanding-our-city/city-waters-viewer/",note:"Council water, stormwater and wastewater infrastructure."},
 {area:"Tauranga",kind:"Underground services",name:"Tauranga Mapi viewer",url:"https://www.tauranga.govt.nz/council/maps/council-map-viewer-mapi",note:"Council GIS viewer; turn on the relevant water service layers."},
 {area:"Wellington City",kind:"Water and drainage",name:"Wellington City Water and Drainage",url:"https://gis.wcc.govt.nz/LocalMapsViewer/?map=57fb534c2174471ca485132112088afc",note:"City map with Wellington Water and council data; verify assets with their owner."},
 {area:"Napier City",kind:"Three waters utility data",name:"Napier three waters GIS layers",url:"https://spatial.napier.govt.nz/server/rest/services/Open/Utilities_Open/MapServer",note:"Council ArcGIS service for utility layers; technical data view rather than a simple public map."},
 {area:"Queenstown Lakes District",kind:"Three waters assets",name:"QLDC Three Waters Assets · ArcGIS",url:"https://hub.arcgis.com/maps/a99d1860d32f44fbb025142a364d0458/about",note:"The user-supplied dataset covers this district only, including water, wastewater and stormwater assets."},
 {area:"Christchurch",kind:"Three waters networks",name:"Christchurch three waters maps",url:"https://ccc.govt.nz/services/water-and-drainage/three-waters-advanced-asset-network-map",note:"Council asset map; follow the council page for current access and caveats."},
 {area:"Canterbury (participating councils)",kind:"Regional three waters data",name:"Canterbury Maps three waters data",url:"https://opendata.canterburymaps.govt.nz/maps/268050a3ebee4fc3861b88122e5b6771/about",note:"Consolidated local authority feeds; coverage varies and may omit assets from a council."},
 {area:"Canterbury",kind:"Wells / bores",name:"Canterbury Wells Search",url:"https://apps.canterburymaps.govt.nz/WellsSearch/",note:"Regional well records and bore logs."},
 {area:"Nelson and Tasman",kind:"Property and utility layers",name:"Top of the South Maps",url:"https://www.nelson.govt.nz/2services/6mapsgis/top-of-the-south-maps",note:"Joint council map service; select pipes and drains layers as needed."},
 {area:"Dunedin",kind:"Three waters reticulation",name:"Dunedin water services map",url:"https://www.dunedin.govt.nz/do-it-online/maps-and-photos/water-services-map-and-wws-work-in-progress",note:"Known council-managed water, stormwater and wastewater networks; most private services excluded."},
 {area:"Otago",kind:"Wells / bores",name:"Otago groundwater bores",url:"https://www.orc.govt.nz/environment/water-care/groundwater/otago-groundwater-bores",note:"Council guidance links to its bore database and maps."},
 {area:"Invercargill and Bluff",kind:"Three waters pipe networks",name:"Invercargill LocalMaps",url:"https://maps.icc.govt.nz/ICCMaps/Viewer/?map=5062871bc9064752b334d617b4c74cd2",note:"Council catalogue describes sewer, stormwater and freshwater pipes; choose the relevant layers."},
 {area:"Southland District",kind:"Underground utilities",name:"Southland LocalMaps",url:"https://gis.southlanddc.govt.nz/localmapspublic/viewer/?webmap=63ff7e215bbe43b1b0d47aeeb893c530",note:"Council's indicative underground services map; confirm locations before works."},
];
type MapItem=(typeof maps)[number];
const groups=["All maps","National & groundwater","North Island networks","South Island networks"] as const;
function groupFor(m:MapItem){if(m.area.startsWith("Nationwide")||m.kind.includes("Wells / bores"))return "National & groundwater";if(["Queenstown Lakes District","Christchurch","Canterbury (participating councils)","Nelson and Tasman","Dunedin","Invercargill and Bluff","Southland District"].includes(m.area))return "South Island networks";return "North Island networks";}
export default function MapsPage(){
 const [query,setQuery]=useState("");const [group,setGroup]=useState<(typeof groups)[number]>("All maps");
 const shown=maps.filter(m=>(group==="All maps"||groupFor(m)===group)&&`${m.area} ${m.kind} ${m.name} ${m.note}`.toLocaleLowerCase("en-NZ").includes(query.trim().toLocaleLowerCase("en-NZ")));
 const sections=group==="All maps"?groups.slice(1):[group];
 return <section className="maps-page"><p className="eyebrow">THREE WATERS & GROUNDWATER</p><h1>Which map<br/><em>answers your question?</em></h1><p className="lead">Choose a purpose or region, then open the map maintained by the relevant council or provider. Public asset coverage and access vary across New Zealand.</p>
 <div className="map-purpose"><div><strong>Locate a supply</strong><span>Use the public drinking water register.</span></div><div><strong>Investigate a bore</strong><span>Use well records and regional quality data.</span></div><div><strong>Inspect assets</strong><span>Use the local owner’s network viewer.</span></div></div>
 <div className="map-controls"><div className="map-tabs" role="group" aria-label="Map category">{groups.map(g=><button key={g} className={group===g?"selected":""} aria-pressed={group===g} onClick={()=>setGroup(g)}>{g}</button>)}</div><label className="map-search">Search place or water topic<input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Southland, bore, wastewater…"/></label></div>
 <p className="scope-note" role="status">Showing {shown.length} of {maps.length} verified resources</p>
 {sections.map(section=>{const items=shown.filter(m=>groupFor(m)===section);return items.length?<section className="map-section" key={section}><h2>{section}</h2><div className="map-grid">{items.map(m=><article className="map-card" key={m.name}><div className="map-card-head"><span>{m.area}</span><small>{m.kind}</small></div><h3>{m.name}</h3><p>{m.note}</p><a href={m.url} target="_blank" rel="noopener noreferrer">Open official map or data <ExternalLink size={15}/></a></article>)}</div></section>:null})}
 {!shown.length&&<div className="empty">No map matches that search. Try a nearby council or a broader term. The Councils tab provides a direct water page for all 78 authorities.</div>}
 <p className="scope-note">The Queenstown Lakes dataset is district-specific; this directory does not form a complete national pipe layer. A mapped bore does not establish that its water is safe to drink. Confirm locations and asset details with the owner before works, and contact the relevant council when a map is missing.</p></section>;
}
