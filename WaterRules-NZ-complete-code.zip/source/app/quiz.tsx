"use client";
import {useEffect,useState} from "react";
import {ExternalLink,RotateCcw} from "lucide-react";
import {questions,type QuizQuestion} from "./quiz-data";

const RULES="https://www.taumataarowai.govt.nz/assets/Drinking-Water-Supplier/Drinking-Water-Quality-Assurance-Rules-2022-Revised-2024.pdf#page=2";
const phrases=[
  {mi:"Ko te wai ahau, ko ahau te wai.",en:"I am wai, wai is me."},
  {mi:"He taonga te wai me tiaki.",en:"Wai is a taonga that must be protected."},
  {mi:"Ko te ora te wai ko te ora o te tangata.",en:"The health of te wai is the health of te tangata."}
];
type Session={day:string;attempt:number;set:QuizQuestion[];phrase:typeof phrases[number]};
function aucklandDay(){const parts=new Intl.DateTimeFormat("en-NZ",{timeZone:"Pacific/Auckland",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(new Date());const find=(part:string)=>parts.find(p=>p.type===part)?.value||"";return `${find("year")}-${find("month")}-${find("day")}`;}
function hash(input:string){let n=2166136261;for(const char of input){n=Math.imul(n^char.charCodeAt(0),16777619)}return n>>>0;}
function makeSession(day:string,attempt:number):Session{const set=[...questions];let seed=hash(`${day}:${attempt}:WaterRules`);for(let i=set.length-1;i>0;i--){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const j=seed%(i+1);[set[i],set[j]]=[set[j],set[i]]}return {day,attempt,set:set.slice(0,10),phrase:phrases[(hash(day)+attempt)%phrases.length]};}

export default function Quiz(){
 const [session,setSession]=useState<Session|null>(null),[step,setStep]=useState(0),[selected,setSelected]=useState<number|null>(null),[checked,setChecked]=useState(false),[score,setScore]=useState(0);
 useEffect(()=>{setSession(makeSession(aucklandDay(),0))},[]);
 if(!session)return <section className="quiz-view"><p className="eyebrow">SUPPLIER KNOWLEDGE CHECK</p><h1>Today’s quiz</h1><p className="lead">Preparing your questions…</p></section>;
 const set=session.set,done=step>=set.length,q=set[step];
 function next(){if(step===set.length-1)setStep(set.length);else{setStep(step+1);setSelected(null);setChecked(false)}}
 function restart(){const day=aucklandDay();setSession(makeSession(day,day===session!.day?session!.attempt+1:0));setStep(0);setSelected(null);setChecked(false);setScore(0)}
 return <section className="quiz-view"><p className="eyebrow">DAILY SUPPLIER KNOWLEDGE CHECK · {session.day}</p><h1>Test what you<br/><em>know.</em></h1><p className="lead">Ten questions chosen from a reviewed bank for today in Aotearoa New Zealand. A new mix appears each day and when you try again. Each answer links to its source.</p>
  <div className="water-phrase"><span>WAI · A THOUGHT FOR THIS ATTEMPT</span><blockquote lang="mi">“{session.phrase.mi}”</blockquote><p>{session.phrase.en} <a href={RULES} target="_blank" rel="noreferrer">Taumata Arowai · Rules, p. 2 <ExternalLink size={13}/></a></p></div>
  {done?<div className="quiz-card quiz-complete"><div className="quiz-score">{score} / {set.length}</div><h2>Quiz complete</h2><p>{score===set.length?"Excellent work. You found the right source-based answer every time.":score>=7?"Strong work. Review the linked explanations for the remaining points and keep practising.":"You made a useful start. Each question is a chance to learn; revisit the source links and try a fresh mix."}</p><button className="quiz-primary" onClick={restart}><RotateCcw size={17}/> Try a new mix</button></div>
  :<div className="quiz-card"><div className="quiz-progress"><span>QUESTION {step+1} OF {set.length}</span><span>{score} correct so far</span></div><div className="progress-track"><div style={{width:`${(step/set.length)*100}%`}}/></div><h2>{q.question}</h2><div className="quiz-options">{q.options.map((option,i)=><button key={i} onClick={()=>!checked&&setSelected(i)} disabled={checked} className={`${selected===i?"chosen":""} ${checked&&i===q.answer?"correct":""} ${checked&&selected===i&&i!==q.answer?"incorrect":""}`}><span>{"ABCD"[i]}</span>{option}</button>)}</div>
   {!checked?<><details className="quiz-hint"><summary>Need a hint?</summary><p>{q.hint}</p></details><button className="quiz-primary" disabled={selected===null} onClick={()=>{setChecked(true);if(selected===q.answer)setScore(score+1)}}>Check answer</button></>
   :<div className="quiz-feedback" aria-live="polite"><strong>{selected===q.answer?"Well done — keep going!":"Good effort — let’s check the source."}</strong><p>{q.feedback[selected!]}</p>{selected!==q.answer&&<p>The best answer is <b>{"ABCD"[q.answer]}. {q.options[q.answer]}</b> {q.feedback[q.answer]}</p>}<a href={q.source} target="_blank" rel="noreferrer">{q.reference} <ExternalLink size={14}/></a><button className="quiz-primary" onClick={next}>{step===set.length-1?"See score":"Next question"}</button></div>}
  </div>}
  <p className="quiz-foot">Question sources reviewed 29 September 2026. The daily mix changes automatically; source content is checked separately. Current 2022 Rules (Revised 2024) remain in effect until 1 July 2027. Confirm your own supply’s pathway before an operational decision.</p>
 </section>;
}
