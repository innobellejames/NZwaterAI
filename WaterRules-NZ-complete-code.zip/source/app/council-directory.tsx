"use client";
import {useMemo,useState} from "react";
import {ExternalLink,Search} from "lucide-react";
import {councils,councilDirectorySource} from "./councils";
import {waterLinks} from "./council-water-links";
const noticeLinks:Record<string,{label:string;url:string}>={
 "Auckland Council":{label:"Watercare boil water notices",url:"https://www.watercare.co.nz/home/projects-and-updates/boil-water-notice"},
 "Christchurch City Council":{label:"Current water shut-offs",url:"https://ccc.govt.nz/services/water-and-drainage/water-supply/maintenance-and-repairs/water-status-map"},
 "Wellington City Council":{label:"Wellington Water network status",url:"https://www.wellingtonwater.co.nz/faults-and-outages/see-outages/network-status"},
 "Dunedin City Council":{label:"Water shutdown notices",url:"https://www.dunedin.govt.nz/news-and-events/public-notices/water-shutdowns"}
};

export default function CouncilDirectory(){
 const [query,setQuery]=useState("");
 const [island,setIsland]=useState("All islands");
 const [type,setType]=useState("All types");
 const shown=useMemo(()=>councils.filter(c=>(!query||c.name.toLocaleLowerCase("en-NZ").includes(query.trim().toLocaleLowerCase("en-NZ")))&&(island==="All islands"||c.island===island)&&(type==="All types"||c.type===type)),[query,island,type]);
 return <section className="council-directory">
  <p className="eyebrow">LOCAL GOVERNMENT DIRECTORY</p>
  <h1>Find your<br/><em>council.</em></h1>
  <p className="lead">Find your council’s water page and check the issuing supplier for current notices, outages or local service information.</p>
  <div className="notice-guide"><strong>Find a live water notice</strong><ol><li><a href="https://hinekorako.taumataarowai.govt.nz/publicregister/supplies/" target="_blank" rel="noopener noreferrer">Look up the drinking water supplier</a> if you are unsure who operates the supply.</li><li>Search the council below and open its direct water page or a dedicated notices link where available.</li><li>Confirm the notice status with the issuing supplier. For urgent safety concerns, follow their advice and <a href="https://www.taumataarowai.govt.nz/for-the-public/drinking-water-in-an-emergency/drinking-water-notices" target="_blank" rel="noopener noreferrer">Taumata Arowai’s notice guidance</a>.</li></ol><p>Regional councils usually cover water resources rather than household supply notices. The direct notice links below are a curated subset, not a live national alert feed.</p></div>
  <div className="council-controls"><label className="council-search"><Search size={18}/><span className="sr-only">Search councils</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search council name"/></label><label><span className="sr-only">Island</span><select value={island} onChange={e=>setIsland(e.target.value)}><option>All islands</option><option>North Island</option><option>South Island</option></select></label><label><span className="sr-only">Council type</span><select value={type} onChange={e=>setType(e.target.value)}><option>All types</option><option>Regional</option><option>City</option><option>District</option><option>Unitary</option></select></label></div>
  <div className="council-table-header"><h2>Water page finder</h2><span>{shown.length} of {councils.length} councils</span></div>
  <div className="table-scroll"><table className="overview-table council-table"><thead><tr><th scope="col">Council</th><th scope="col">Water / groundwater page</th><th scope="col">Notices & outages</th><th scope="col">Council home</th></tr></thead><tbody>{shown.map(c=><tr key={c.name}><th scope="row">{c.name}<small>{c.island} · {c.type}</small></th><td><a href={waterLinks[c.name]||c.url} target="_blank" rel="noopener noreferrer">Open water page <ExternalLink size={14}/></a></td><td>{noticeLinks[c.name]?<a href={noticeLinks[c.name].url} target="_blank" rel="noopener noreferrer">{noticeLinks[c.name].label} <ExternalLink size={14}/></a>:<span className="notice-fallback">Check the water page or contact the provider</span>}</td><td><a href={c.url} target="_blank" rel="noopener noreferrer">Council site <ExternalLink size={14}/></a></td></tr>)}</tbody></table></div>
  {!shown.length&&<p className="council-empty">No council matches these filters. Try a shorter name or reset the filters.</p>}
  <p className="scope-note">Council names and homepages are based on <a href={councilDirectorySource} target="_blank" rel="noopener noreferrer">LGNZ’s directory</a>. Direct pages were researched 29 September 2026 and can move; use the council home link if one does. A listed council is not necessarily your supply operator. Ask the council for local details and <a href="https://www.taumataarowai.govt.nz/contact-us" target="_blank" rel="noopener noreferrer">Taumata Arowai</a> where regulator guidance is unclear.</p>
 </section>;
}
